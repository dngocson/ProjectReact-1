import Card from "../../component/UI/Card";
import { NavLink } from "react-router-dom";
const Categories = ({ imgSrc, name }) => {
  return (
    <Card>
      <div className="col-span-1">
        <NavLink to={`/product/${name}`}>
          <img src={imgSrc}></img>
          <p>{name}</p>
        </NavLink>
      </div>
    </Card>
  );
};

export default Categories;
