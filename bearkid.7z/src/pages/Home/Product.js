import { NavLink } from "react-router-dom";
import { useDispatch } from "react-redux";
import { cartActions } from "../../store/cart-slice";
const Product = ({ title, price, id, image }) => {
  const dispatch = useDispatch();
  const addItemtoCart = () => {
    dispatch(cartActions.addItemtoCart({ id, price, title }));
  };
  return (
    <div className="flex items-center flex-col">
      <NavLink to={`/product/detail/${id}`}>
        <img className="h-48 w-48" src={image} />
      </NavLink>
      {/* <span>{title}</span> */}
      <span>{price}</span>
      <button className="text-red-500" onClick={addItemtoCart}>
        addItemtoCart
      </button>
    </div>
  );
};

export default Product;
