import { Fragment } from "react";
import Map from "../component/general/Map";
function About() {
  return (
    <Fragment>
      <h1>About</h1>
      <Map />
    </Fragment>
  );
}
export default About;
