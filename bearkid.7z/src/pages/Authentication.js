import AuthForm from "../component/general/AuthForm";
import { json, redirect } from "react-router-dom";
import { firebaseAuth as auth, googleProvider } from "../config/firebase";
import {
  createUserWithEmailAndPassword,
  signInWithPopup,
  signInWithEmailAndPassword,
} from "firebase/auth";
import Cookies from "universal-cookie";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
const cookies = new Cookies();

function Authentication() {
  ///////////////////
  const [test, setTest] = useState(0);
  /////////
  const navigate = useNavigate();
  const signInWithGoogleHandler = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      cookies.set("auth-token", result.user.refreshToken);
      navigate("/");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <h1>Authentication</h1>
      <AuthForm />
      <button onClick={signInWithGoogleHandler}>Sign In with google</button>
      <button onClick={() => setTest(test + 1)}>1234</button>
    </>
  );
}
export default Authentication;
export async function action({ request }) {
  try {
    const searchParams = new URL(request.url).searchParams;
    const mode = searchParams.get("mode") || "login";
    if (mode !== "login" && mode !== "signup") {
      throw json({ message: "Unsupported mode" }, { status: 500 });
    }
    const data = await request.formData();
    const authData = {
      email: data.get("email"),
      password: data.get("password"),
    };
    if (mode === "signup") {
      const result = await createUserWithEmailAndPassword(
        auth,
        authData.email,
        authData.password
      );
      cookies.set("auth-token", result.user.refreshToken);
    }
    if (mode === "login") {
      await signInWithEmailAndPassword(auth, authData.email, authData.password);
    }
    return redirect("/");
  } catch (error) {
    console.error(error);
  }
}
