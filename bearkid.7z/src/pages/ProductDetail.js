import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { cartActions } from "../store/cart-slice";
const ProductDetail = () => {
  const params = useParams();
  const dispatch = useDispatch();
  const id = params.productId;
  const listofProduct = useSelector((state) => state.shop.shopItem);
  const [currentProduct = []] = listofProduct.filter(
    (product) => `${product.id}` === id
  );
  const addtoCartHandler = () => {
    dispatch(
      cartActions.addItemtoCart({
        id: currentProduct.id,
        price: currentProduct.price,
        title: currentProduct.title,
      })
    );
  };

  return (
    <div>
      <img className="h-48 w-48" src={currentProduct.image} />
      <h3>{currentProduct.title}</h3>
      <h4>{currentProduct.description}</h4>
      <button className="text-red-500" onClick={addtoCartHandler}>
        Add to Cart
      </button>
    </div>
  );
};

export default ProductDetail;
