function Carosel() {
  return <h1>Carosel</h1>;
}
export default Carosel;
