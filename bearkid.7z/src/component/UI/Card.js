const Card = ({ children }) => {
  return (
    <div className="bg-slate-400 shadow-md rounded-md overflow-hidden">
      {children}
    </div>
  );
};

export default Card;
