import {
  Fragment,
  useMemo,
  useState,
  useCallback,
  useRef,
  useEffect,
} from "react";
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Icon, divIcon, point } from "leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";

const zoom = 13;
const markers = [
  {
    geocode: [10.7834141, 106.70062335],
    popup: "No. 4 Le Duan, District 1, Ho Chi Minh City",
    index: 0,
  },
  {
    geocode: [10.7776076, 106.68806858],
    popup: "No. 40 Ba Huyen Thanh Quan, District 3, Ho Chi Minh City",
    index: 1,
  },
  {
    geocode: [10.80103, 106.6391892],
    popup:
      "450 Truong Chinh, Ward 13, Tan Binh District, Ho Chi Minh City, Vietnam.",
    index: 2,
  },
];

function DisplayPosition({
  map,
  markerRef,
  userlocation,
  fetchUserLocation,
  errorMessage,
  userIconRef,
}) {
  const onClick = useCallback(
    (location) => {
      map.flyTo(location.geocode, zoom);
      markerRef.current[location.index].openPopup();
    },
    [map, markerRef]
  );
  const moveToUserPos = useCallback(
    (location) => {
      map.flyTo(location, zoom);
      userIconRef.current.openPopup();
    },
    [map]
  );
  return (
    <div>
      <h3> Our location:</h3>
      <div>
        {markers.map((location) => (
          <p key={location.index}>
            <span>{location.popup}</span>
            <button className="text-red-500" onClick={() => onClick(location)}>
              View on map
            </button>
          </p>
        ))}
        {!userlocation.length > 0 && (
          <button className="text-orange-600" onClick={fetchUserLocation}>
            Fetch location
          </button>
        )}
        {errorMessage && <p>{errorMessage}</p>}
        {!errorMessage && userlocation.length > 0 && (
          <button
            className="text-orange-600"
            onClick={() => moveToUserPos(userlocation)}
          >
            Move to your Position
          </button>
        )}
      </div>
    </div>
  );
}

function Map() {
  const [map, setMap] = useState(null);
  const markerRef = useRef([]);
  const userIconRef = useRef();
  const [userlocation, setUserLocation] = useState([]);
  const [errorMessage, setErrorMessage] = useState(null);
  const fetchUserLocation = function () {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation([latitude, longitude]);
        setErrorMessage(null);
      },
      (error) => {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setErrorMessage(
              "User denied the request for Geolocation. Please check your broser setting and try again"
            );
            break;
          case error.POSITION_UNAVAILABLE:
            setErrorMessage("Location information is unavailable.");
            break;
          case error.TIMEOUT:
            setErrorMessage("The request to get user location timed out.");
            break;
          case error.UNKNOWN_ERROR:
            setErrorMessage("An unknown error occurred.");
            break;
        }
      }
    );
  };
  useEffect(() => {
    fetchUserLocation();
  }, [errorMessage]);

  const customIcon = useMemo(
    () =>
      new Icon({
        iconUrl: "https://cdn-icons-png.flaticon.com/512/9441/9441481.png",
        iconSize: [35, 35],
      }),
    []
  );
  const userIcon = useMemo(
    () =>
      new Icon({
        iconUrl: "https://cdn-icons-png.flaticon.com/512/1365/1365700.png",
        iconSize: [40, 40],
      }),
    []
  );
  const createClusterCustomIcon = function (cluster) {
    return new divIcon({
      html: `<span class="cluster-icon">${cluster.getChildCount()}</span>`,
      className: "custom-marker-cluster",
      iconSize: point(33, 33, true),
    });
  };

  const displayMap = useMemo(() => {
    const haveLocation = userlocation.length > 1;
    return (
      <MapContainer
        className="h-96 z-1"
        center={[10.777262, 106.688116]}
        zoom={12}
        zoomControl={false}
        ref={setMap}
      >
        <TileLayer
          attribution="Do Ngoc Son"
          url="http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}"
          subdomains={["mt0", "mt1", "mt2", "mt3"]}
        />
        <MarkerClusterGroup
          chunkedLoading
          iconCreateFunction={createClusterCustomIcon}
        >
          {markers.map((marker, index) => (
            <Marker
              key={index}
              position={marker.geocode}
              icon={customIcon}
              ref={(ref) => (markerRef.current[index] = ref)}
            >
              <Popup>{marker.popup}</Popup>
            </Marker>
          ))}
        </MarkerClusterGroup>
        {haveLocation && (
          <Marker ref={userIconRef} position={userlocation} icon={userIcon}>
            <Popup
              closeButton={false}
              autoClose={false}
            >{`Your Location`}</Popup>
          </Marker>
        )}
      </MapContainer>
    );
  }, [customIcon, userlocation]);

  return (
    <Fragment>
      {map ? (
        <DisplayPosition
          map={map}
          markerRef={markerRef}
          fetchUserLocation={fetchUserLocation}
          errorMessage={errorMessage}
          userlocation={userlocation}
          userIconRef={userIconRef}
        />
      ) : null}
      {displayMap}
    </Fragment>
  );
}

export default Map;
