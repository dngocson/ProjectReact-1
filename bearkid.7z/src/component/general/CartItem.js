import { useDispatch } from "react-redux";

import { cartActions } from "../../store/cart-slice";
const CartItem = (props) => {
  const dispatch = useDispatch();
  const { title, quantity, total, price, id } = props.item;
  const removeItemHandler = () => {
    dispatch(cartActions.removeItemFromCart({ id, price }));
  };

  const addItemHandler = () => {
    dispatch(
      cartActions.addItemtoCart({
        id,
        title,
        price,
      })
    );
  };

  return (
    <li className="border-b-4">
      <header>
        <span className="text-2xl">{title}</span>
        <div className="text-xl">
          ${total.toFixed(2)}
          <span className="text-xl">(${price.toFixed(2)}/item)</span>
        </div>
      </header>
      <div className="">
        <div className="">
          x <span>{quantity}</span>
        </div>
        <div className="">
          <button onClick={removeItemHandler}>-</button>
          <button onClick={addItemHandler}>+</button>
        </div>
      </div>
    </li>
  );
};

export default CartItem;
