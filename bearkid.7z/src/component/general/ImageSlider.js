import classes from "./ImageSlider.module.css";
import { useState, useEffect } from "react";
const slides = [
  {
    // url: "https://images.unsplash.com/photo-1566004100631-35d015d6a491?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "img1",
  },
  {
    // url: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1175&q=80",
    title: "img2",
  },
  {
    // url: "https://images.unsplash.com/photo-1544829832-c8047d6b9d89?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    title: "img3",
  },
  {
    // url: "https://plus.unsplash.com/premium_photo-1661546413455-ce42b866efc8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1187&q=80",
    title: "img4",
  },
  {
    // url: "https://images.unsplash.com/photo-1551934262-db2d7dd517f4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1077&q=80",
    title: "img5",
  },
];
function ImageSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);
  let slideClass = "slideStyles"; // Set the default class name
  // Update slideClass based on the value of currentIndex
  if (currentIndex === 0) {
    slideClass = "slideStyles1";
  } else if (currentIndex === 1) {
    slideClass = "slideStyles2";
  } else if (currentIndex === 2) {
    slideClass = "slideStyles3";
  } else if (currentIndex === 3) {
    slideClass = "slideStyles4";
  } else if (currentIndex === 4) {
    slideClass = "slideStyles5";
  }
  useEffect(() => {
    const timeout = setTimeout(() => {
      const isLastSlide = currentIndex === slides.length - 1;
      const newIndex = isLastSlide ? 0 : currentIndex + 1;
      setCurrentIndex(newIndex);
    }, 3000); // Change slide every 3 seconds

    return () => clearTimeout(timeout);
  }, [currentIndex, slides]);

  const gotoLeft = () => {
    const isFirstSlide = currentIndex === 0;
    const newIndex = isFirstSlide ? slides.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
  };
  const gotoRight = () => {
    const isLastSlide = currentIndex === slides.length - 1;
    const newIndex = isLastSlide ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
  };
  const gotoSlide = (index) => {
    setCurrentIndex(index);
  };

  return (
    <div className={classes.sliderStyles}>
      <div className={classes.leftArrowStyles} onClick={gotoLeft}>
        &lt;
      </div>
      <div className={classes.rightArrowStyles} onClick={gotoRight}>
        &gt;
      </div>
      <div className={`${classes[slideClass]}`}></div>
      <div className={classes.dotsContainerStyles}>
        {slides.map((slide, slideIndex) => (
          <div
            className={`${classes.dotStyles} ${
              currentIndex === slideIndex ? classes.dotActive : ""
            }`}
            key={slide.title}
            onClick={() => gotoSlide(slideIndex)}
          >
            ●
          </div>
        ))}
      </div>
    </div>
  );
}

export default ImageSlider;
