import { NavLink } from "react-router-dom";
const NavigationButton = ({ desc, label }) => {
  return (
    <li>
      {
        <NavLink
          to={desc}
          className="text-white aria-[current=page]:text-blue-400"
        >
          {label}
        </NavLink>
      }
    </li>
  );
};

export default NavigationButton;
