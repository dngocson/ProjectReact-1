import NavigationButton from "./NavigationButton";
const items = [
  { label: "Home", desc: "/" },
  { label: "All product", desc: "/product/" },
  { label: "Clothes", desc: "/product/clothes" },
  { label: "Electronic", desc: "/product/electronic" },
  { label: "Furniture", desc: "/product/furniture" },
  { label: "Shoes", desc: "/product/shoes" },
  { label: "About", desc: "/about" },
];
function Navigation() {
  return (
    <ul className="flex justify-around">
      {items.map((item, index) => (
        <NavigationButton desc={item.desc} label={item.label} key={index} />
      ))}
    </ul>
  );
}
export default Navigation;
