import { BiCart } from "react-icons/bi";
import { useDispatch } from "react-redux";
import { uiActions } from "../../store/ui-slice";
import { useSelector } from "react-redux";
const HeaderCartButton = (props) => {
  const dispatch = useDispatch();
  const totalProduct = useSelector((state) => state.cart.totalQuantity);
  const displayCart = () => {
    dispatch(uiActions.setDisplayCart());
  };
  return (
    <button className="flex align-middle items-center" onClick={displayCart}>
      <span>
        <BiCart />
      </span>
      <span>{totalProduct}</span>
    </button>
  );
};

export default HeaderCartButton;
