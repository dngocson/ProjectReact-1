import { Fragment } from "react";
import ImageSlider from "./ImageSlider";
import SearchBar from "./SearchBar";
import Navigation from "./Navigation";
import HeaderCartButton from "./HeaderCartButton";
import { Link } from "react-router-dom";
import { signOut } from "firebase/auth";
import { firebaseAuth as auth } from "../../config/firebase";
import { useSelector } from "react-redux";
import Cookies from "universal-cookie";
import { cartActions } from "../../store/cart-slice";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
const cookies = new Cookies();
function Header() {
  const navigate = useNavigate();
  const isAuth = useSelector((state) => state.ui.isAuth);
  const dispatch = useDispatch();
  const signOutHandler = async () => {
    try {
      await signOut(auth);
      cookies.remove("auth-token");
      dispatch(cartActions.clearCart());
      navigate("/auth");
    } catch (err) {
      console.error(err);
    }
  };
  return (
    <Fragment>
      <header>
        <div className="bg-red-300">
          <div className="flex justify-around p-4">
            <h1>Bearkid</h1>
            <SearchBar />
            <div className="flex gap-10 ">
              {!isAuth && <Link to={"/auth"}>login</Link>}
              {isAuth && <button onClick={signOutHandler}> Sign Out</button>}
              <HeaderCartButton />
            </div>
          </div>
          <Navigation />
        </div>
        <div>
          <ImageSlider />
        </div>
      </header>
    </Fragment>
  );
}
export default Header;
