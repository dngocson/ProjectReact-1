function SearchBar() {
  return (
    <section>
      <form>
        <input type="text"></input>
        <button>search</button>
      </form>
    </section>
  );
}
export default SearchBar;
