import { useSelector } from "react-redux";
import CartItem from "./CartItem";
import { useDispatch } from "react-redux";
import { sendDataToFireStore } from "../../store/sendDataToFireStore";
const ModalOverlay = () => {
  const cartItems = useSelector((state) => state.cart.items);
  const totalPrice = useSelector((state) => state.cart.totalAmount);
  const hasItems = cartItems.length > 0;
  const dispatch = useDispatch();
  const sendDataHandler = () => {
    dispatch(sendDataToFireStore());
  };
  return (
    <div className="fixed z-30 h-3/6 w-3/6 bg-red-600">
      <ul>
        {cartItems.map((item) => (
          <CartItem
            key={item.id}
            item={{
              id: item.id,
              title: item.title,
              quantity: item.quantity,
              total: item.totalPrice,
              price: item.price,
            }}
          />
        ))}
      </ul>
      {hasItems ? (
        <span>Total price : {totalPrice.toFixed(2)}</span>
      ) : (
        <p>No items in cart, please select some item</p>
      )}
      <button onClick={sendDataHandler}>Send</button>
    </div>
  );
};

export default ModalOverlay;
