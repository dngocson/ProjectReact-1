import { useSelector } from "react-redux";
import { db } from "../config/firebase";
import { getDocs } from "firebase/firestore";
export const getDataToFireStore = () => {
  return async (dispath) => {};
};
