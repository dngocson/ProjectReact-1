import { db } from "../config/firebase";
import {
  collection,
  addDoc,
  updateDoc,
  query,
  where,
  getDocs,
} from "firebase/firestore";

export const sendDataToFireStore = () => {
  return async (dispatch, getState) => {
    const state = getState();
    const cartItems = state.cart.items;
    const totalPrice = state.cart.totalAmount;
    const currentId = state.ui.uid;
    const cartCollection = collection(db, "Cart");
    console.log(currentId);
    try {
      const q = query(cartCollection, where("uid", "==", currentId));
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) {
        await addDoc(cartCollection, {
          items: cartItems,
          totalPayAmount: totalPrice,
          uid: state.ui.uid,
        });
      } else {
        querySnapshot.forEach((doc) => {
          updateDoc(doc.ref, {
            items: cartItems,
            totalPayAmount: totalPrice,
            uid: currentId,
          });
        });
      }
    } catch (err) {
      console.error(err);
    }
  };
};
