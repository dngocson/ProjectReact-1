import { createBrowserRouter, RouterProvider } from "react-router-dom";
import HomePage from "./pages/Home/Home";
import About from "./pages/About";
import Authentication, { action as authAction } from "./pages/Authentication";
import Detail from "./pages/Product";
import RootLayout from "./pages/RootLayout";
import ProductDetail from "./pages/ProductDetail";
import "./App.css";
import { useEffect } from "react";
import { fetchShopItem } from "./store/fetchShopItem-action";
import { resumeAuthstate } from "./store/resumeAuth-action";
import { useDispatch } from "react-redux";
import ErrorPage from "./pages/Error";
const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "about",
        element: <About />,
      },
      {
        path: "product",
        element: <Detail />,
      },
      {
        path: "product/detail/:productId",
        element: <ProductDetail />,
      },
      {
        path: "auth",
        element: <Authentication />,
        action: authAction,
      },
    ],
  },
]);
function App() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchShopItem());
    dispatch(resumeAuthstate());
  }, [dispatch]);
  return <RouterProvider router={router} />;
}

export default App;
